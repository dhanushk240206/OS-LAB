#include <stdio.h>

// Maximum number of processes
#define MAX 20

// Global Variables
int n, i, j;
int Burst_time[MAX], Arrival_time[MAX], Waiting_time[MAX], Turn_around_time[MAX], Completion_time[MAX], process[MAX];
float avg_Turn_around_time = 0, avg_Waiting_time = 0;

// Function to sort processes by their arrival time
void sortByArrival() {
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if (Arrival_time[i] > Arrival_time[j]) {
                // Swap Arrival Time
                int temp = Arrival_time[i];
                Arrival_time[i] = Arrival_time[j];
                Arrival_time[j] = temp;

                // Swap Burst Time
                temp = Burst_time[i];
                Burst_time[i] = Burst_time[j];
                Burst_time[j] = temp;

                // Swap Process ID
                temp = process[i];
                process[i] = process[j];
                process[j] = temp;
            }
        }
    }
}

// Function to execute FCFS Scheduling
void FCFS() {
    sortByArrival();  // Sort based on arrival time

    // Calculate Completion, Turnaround, and Waiting Times for the first process
    Completion_time[0] = Arrival_time[0] + Burst_time[0];
    Turn_around_time[0] = Completion_time[0] - Arrival_time[0];
    Waiting_time[0] = Turn_around_time[0] - Burst_time[0];

    // Calculate for the remaining processes
    for (i = 1; i < n; i++) {
        if (Arrival_time[i] > Completion_time[i - 1]) {
            // If the next process arrives after the previous one is complete
            Completion_time[i] = Arrival_time[i] + Burst_time[i];
        } else {
            // If the next process arrives while the CPU is busy
            Completion_time[i] = Completion_time[i - 1] + Burst_time[i];
        }

        // Turnaround Time = Completion Time - Arrival Time
        Turn_around_time[i] = Completion_time[i] - Arrival_time[i];
        // Waiting Time = Turnaround Time - Burst Time
        Waiting_time[i] = Turn_around_time[i] - Burst_time[i];
    }

    // Display the results in table format
    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time");
    for (i = 0; i < n; i++) {
        avg_Waiting_time += Waiting_time[i];
        avg_Turn_around_time += Turn_around_time[i];
        printf("\nP[%d]\t\t%d\t\t%d\t\t%d\t\t%d", process[i], Arrival_time[i], Burst_time[i], Waiting_time[i], Turn_around_time[i]);
    }

    // Calculate Average Waiting Time and Average Turnaround Time
    avg_Waiting_time /= n;
    avg_Turn_around_time /= n;

    printf("\n\nAverage Waiting Time: %.2f", avg_Waiting_time);
    printf("\nAverage Turnaround Time: %.2f\n", avg_Turn_around_time);
}

// Main function to take user input and call FCFS
int main() {
    printf("Enter the total number of processes: ");
    scanf("%d", &n);

    for (i = 0; i < n; i++) {
        printf("\nEnter Arrival Time for P[%d]: ", i + 1);
        scanf("%d", &Arrival_time[i]);
        printf("Enter Burst Time for P[%d]: ", i + 1);
        scanf("%d", &Burst_time[i]);
        process[i] = i + 1;
    }

    // Execute FCFS Scheduling
    FCFS();
    return 0;
}
