#include <stdio.h>

struct Process {
    int id, at, bt, rt, wt, tat, completed;
};

int main() {
    int n, i, time = 0, tq, remain;
    struct Process p[10];
    float awt = 0, atat = 0;

    printf("Enter the number of processes: ");
    scanf("%d", &n);
    remain = n;

    for (i = 0; i < n; i++) {
        p[i].id = i + 1;
        printf("Enter Arrival Time and Burst Time for Process %d: ", p[i].id);
        scanf("%d %d", &p[i].at, &p[i].bt);
        p[i].rt = p[i].bt;
        p[i].completed = 0;
    }

    printf("Enter Time Quantum: ");
    scanf("%d", &tq);

    int done = 0;
    while (remain > 0) {
        done = 1;
        for (i = 0; i < n; i++) {
            if (p[i].rt > 0 && p[i].at <= time) {
                done = 0;
                if (p[i].rt > tq) {
                    time += tq;
                    p[i].rt -= tq;
                } else {
                    time += p[i].rt;
                    p[i].wt = time - p[i].bt - p[i].at;
                    p[i].tat = time - p[i].at;
                    p[i].rt = 0;
                    p[i].completed = 1;
                    remain--;
                }
            }
        }
        if (done) time++;
    }

    printf("\nPROCESS\tAT\tBT\tWT\tTAT\n");
    for (i = 0; i < n; i++) {
        awt += p[i].wt;
        atat += p[i].tat;
        printf("P%d\t%d\t%d\t%d\t%d\n", p[i].id, p[i].at, p[i].bt, p[i].wt, p[i].tat);
    }

    printf("\nAverage Waiting Time: %.2f", awt / n);
    printf("\nAverage Turnaround Time: %.2f\n", atat / n);

    return 0;
}
