#include<stdio.h>

int n, i, j, pos, temp, Burst_time[20], Arrival_time[20], Waiting_time[20], Turn_around_time[20], Completion_time[20], process[20], total = 0;
float avg_Turn_around_time = 0, avg_Waiting_time = 0;

void sortByArrivalAndBurst() {
 
    for (i = 0; i < n - 1; i++) {
        for (j = i + 1; j < n; j++) {
            if (Arrival_time[i] > Arrival_time[j] || (Arrival_time[i] == Arrival_time[j] && Burst_time[i] > Burst_time[j])) {
         
                int temp_arrival = Arrival_time[i];
                Arrival_time[i] = Arrival_time[j];
                Arrival_time[j] = temp_arrival;

        
                int temp_burst = Burst_time[i];
                Burst_time[i] = Burst_time[j];
                Burst_time[j] = temp_burst;

                int temp_process = process[i];
                process[i] = process[j];
                process[j] = temp_process;
            }
        }
    }
}

int SJF() {
    sortByArrivalAndBurst(); 

    Completion_time[0] = Arrival_time[0] + Burst_time[0];
    Turn_around_time[0] = Completion_time[0] - Arrival_time[0];
    Waiting_time[0] = Turn_around_time[0] - Burst_time[0]; 

    for (i = 1; i < n; i++) {
       
        if (Arrival_time[i] >= Completion_time[i - 1]) {
            Completion_time[i] = Arrival_time[i] + Burst_time[i]; 
        } else {
            Completion_time[i] = Completion_time[i - 1] + Burst_time[i]; 
        }

        Turn_around_time[i] = Completion_time[i] - Arrival_time[i]; 
        Waiting_time[i] = Turn_around_time[i] - Burst_time[i]; 
    }

    avg_Waiting_time = 0;
    total = 0;

    printf("\nProcess\tArrival Time\tBurst Time\tWaiting Time\tTurnaround Time");

    for (i = 0; i < n; i++) {
        total += Turn_around_time[i];
        avg_Waiting_time += Waiting_time[i];
        printf("\nP[%d]\t%d\t\t%d\t\t%d\t\t%d", process[i], Arrival_time[i], Burst_time[i], Waiting_time[i], Turn_around_time[i]);
    }

    avg_Waiting_time /= n;
    avg_Turn_around_time = (float)total / n;

    printf("\n\nAverage Waiting Time=%.2f", avg_Waiting_time);
    printf("\nAverage Turnaround Time=%.2f\n", avg_Turn_around_time);

    return 0;
}

int main() {
    printf("Enter the total number of processes: ");
    scanf("%d", &n);


    for (i = 0; i < n; i++) {
        printf("Enter Arrival Time for P[%d]: ", i + 1);
        scanf("%d", &Arrival_time[i]);
        printf("Enter Burst Time for P[%d]: ", i + 1);
        scanf("%d", &Burst_time[i]);
        process[i] = i + 1;
    }

    SJF();

    return 0;
}
